class paddle{
    constructor(x, y, mp,){
        this.x = x;
        this.y = y;
        this.mp = mp;

    }
    //draws the rectangles
    draw(){

    }
    //controls
    update(){
        
    }
}